package test;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* WestminsterSkinConsultationManager Tester. 
* 
* @author <Authors name> 
* @since <pre>Jan 9, 2023</pre> 
* @version 1.0 
*/ 
public class WestminsterSkinConsultationManagerTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: addDoctor(Doctor doctor) 
* 
*/ 
@Test
public void testAddDoctor() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: removeDoctor(Doctor doctor) 
* 
*/ 
@Test
public void testRemoveDoctor() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getDoctors() 
* 
*/ 
@Test
public void testGetDoctors() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: bookConsultation(Consultation consultation) 
* 
*/ 
@Test
public void testBookConsultation() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: cancelConsultation(Consultation consultation) 
* 
*/ 
@Test
public void testCancelConsultation() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getConsultations() 
* 
*/ 
@Test
public void testGetConsultations() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: printDoctors() 
* 
*/ 
@Test
public void testPrintDoctors() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: saveData() 
* 
*/ 
@Test
public void testSaveData() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: loadData() 
* 
*/ 
@Test
public void testLoadData() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: showMenu() 
* 
*/ 
@Test
public void testShowMenu() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: main(String[] args) 
* 
*/ 
@Test
public void testMain() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: addConsultation(Consultation consultation) 
* 
*/ 
@Test
public void testAddConsultation() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getAvailableDoctors(String text, String text1) 
* 
*/ 
@Test
public void testGetAvailableDoctors() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getConsultationsForDoctor(Doctor doctor) 
* 
*/ 
@Test
public void testGetConsultationsForDoctor() throws Exception { 
//TODO: Test goes here... 
} 


} 
