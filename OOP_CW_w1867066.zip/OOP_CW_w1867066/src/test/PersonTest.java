package test;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* Person Tester. 
* 
* @author <Authors name> 
* @since <pre>Jan 9, 2023</pre> 
* @version 1.0 
*/ 
public class PersonTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getName() 
* 
*/ 
@Test
public void testGetName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setName(String name) 
* 
*/ 
@Test
public void testSetName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getSurname() 
* 
*/ 
@Test
public void testGetSurname() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setSurname(String surname) 
* 
*/ 
@Test
public void testSetSurname() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getDateOfBirth() 
* 
*/ 
@Test
public void testGetDateOfBirth() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setDateOfBirth(Date dateOfBirth) 
* 
*/ 
@Test
public void testSetDateOfBirth() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getMobileNumber() 
* 
*/ 
@Test
public void testGetMobileNumber() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setMobileNumber(String mobileNumber) 
* 
*/ 
@Test
public void testSetMobileNumber() throws Exception { 
//TODO: Test goes here... 
} 


} 
