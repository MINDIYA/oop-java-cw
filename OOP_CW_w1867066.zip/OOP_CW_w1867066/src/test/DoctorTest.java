package test;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* Doctor Tester. 
* 
* @author <Authors name> 
* @since <pre>Jan 9, 2023</pre> 
* @version 1.0 
*/ 
public class DoctorTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getMedicalLicenseNumber() 
* 
*/ 
@Test
public void testGetMedicalLicenseNumber() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setMedicalLicenseNumber(String medicalLicenseNumber) 
* 
*/ 
@Test
public void testSetMedicalLicenseNumber() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getSpecialisation() 
* 
*/ 
@Test
public void testGetSpecialisation() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setSpecialisation(String specialisation) 
* 
*/ 
@Test
public void testSetSpecialisation() throws Exception { 
//TODO: Test goes here... 
} 


} 
