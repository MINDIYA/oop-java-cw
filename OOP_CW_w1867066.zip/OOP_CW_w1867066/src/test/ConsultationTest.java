package test;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* Consultation Tester. 
* 
* @author <Authors name> 
* @since <pre>Jan 9, 2023</pre> 
* @version 1.0 
*/ 
public class ConsultationTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getDate() 
* 
*/ 
@Test
public void testGetDate() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setDate(Date date) 
* 
*/ 
@Test
public void testSetDate() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getTimeSlot() 
* 
*/ 
@Test
public void testGetTimeSlot() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setTimeSlot(String timeSlot) 
* 
*/ 
@Test
public void testSetTimeSlot() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getCost() 
* 
*/ 
@Test
public void testGetCost() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setCost(double cost) 
* 
*/ 
@Test
public void testSetCost() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getNotes() 
* 
*/ 
@Test
public void testGetNotes() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setNotes(String notes) 
* 
*/ 
@Test
public void testSetNotes() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getDoctor() 
* 
*/ 
@Test
public void testGetDoctor() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setDoctor(Doctor doctor) 
* 
*/ 
@Test
public void testSetDoctor() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getPatient() 
* 
*/ 
@Test
public void testGetPatient() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setPatient(Patient patient) 
* 
*/ 
@Test
public void testSetPatient() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getTime() 
* 
*/ 
@Test
public void testGetTime() throws Exception { 
//TODO: Test goes here... 
} 


} 
